import time
import logging
import socket
from pathlib import Path
from zeep import Client, Transport
from zeep.plugins import HistoryPlugin
from zeep.exceptions import Fault
from xml.dom.minidom import parseString
from lxml import etree
import re

# --- Configuration ---
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [Watcher] %(message)s",
    datefmt="%H:%M:%S"
)

ORCHESTRATEUR_WSDL = "http://orchestrateur:8000/OrchestrateurService?wsdl"
DEMANDES_DIR = Path("./demandes")
RESULTATS_DIR = Path("./resultats")


def prettify_xml(xml_string: str) -> str:
    try:
        return parseString(xml_string).toprettyxml(indent="  ")
    except Exception:
        return xml_string


def attendre_orchestrateur(host="orchestrateur", port=8000, timeout=60):
    start = time.time()
    while time.time() - start < timeout:
        try:
            with socket.create_connection((host, port), timeout=2):
                logging.info("✅ Orchestrateur disponible !")
                return True
        except OSError:
            logging.info("⏳ En attente de l'orchestrateur...")
            time.sleep(2)
    logging.error("❌ Impossible de contacter l'orchestrateur après 60s.")
    return False


def envoyer_au_orchestrateur(id_demande, texte_demande):
    try:
        history = HistoryPlugin()
        client = Client(ORCHESTRATEUR_WSDL, transport=Transport(), plugins=[history])
        client.service.evaluateLoan(texte_demande, int(id_demande))
        raw_envelope = history.last_received["envelope"]
        xml_string = etree.tostring(raw_envelope, encoding="unicode")
        return prettify_xml(xml_string)
    except Fault as f:
        logging.error(f"⚠️ Fault SOAP : {f}")
    except Exception as e:
        logging.error(f"❌ Erreur Zeep : {e}")
    return None


def traiter_fichier(username, file_path):
    file_path = Path(file_path)
    try:
        texte = file_path.read_text(encoding="utf-8")
    except Exception as e:
        logging.error(f"❌ Lecture échouée : {e}")
        return

    # Extraire ID (dernier chiffre du nom)
    match = re.search(r"_(\d+)\.txt$", file_path.name)
    id_demande = int(match.group(1)) if match else 1

    logging.info(f"📨 Nouvelle demande user={username}, id={id_demande}")
    result = envoyer_au_orchestrateur(id_demande, texte)

    if result:
        user_result_dir = RESULTATS_DIR / username
        user_result_dir.mkdir(parents=True, exist_ok=True)
        result_name = file_path.stem + "_result.xml"
        out_path = user_result_dir / result_name
        out_path.write_text(result, encoding="utf-8")
        logging.info(f"💾 Résultat XML sauvegardé : {out_path}")
    else:
        logging.warning(f"⚠️ Pas de résultat pour demande {file_path.name}")



def main():
    DEMANDES_DIR.mkdir(parents=True, exist_ok=True)
    RESULTATS_DIR.mkdir(parents=True, exist_ok=True)
    logging.info("🚀 Watcher démarré...")

    if not attendre_orchestrateur():
        return

    traitees = set()
    while True:
        for user_folder in DEMANDES_DIR.iterdir():
            if not user_folder.is_dir():
                continue

            username = user_folder.name  # e.g., jean_dupont
            fichiers = sorted(user_folder.glob("*.txt"), key=lambda f: f.stat().st_mtime)
            if fichiers:
                dernier = fichiers[-1]
                if dernier not in traitees:
                    traiter_fichier(username, dernier)
                    traitees.add(dernier)

        time.sleep(5)


if __name__ == "__main__":
    main()
