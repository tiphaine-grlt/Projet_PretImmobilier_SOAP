import logging
import sys
from spyne import Application, rpc, ServiceBase, Unicode, Integer, ComplexModel, Float
from spyne.protocol.soap import Soap11
from spyne.server.wsgi import WsgiApplication
from spyne.util.wsgi_wrapper import run_twisted
from zeep import Client, Transport
from zeep.exceptions import Fault

logging.basicConfig(level=logging.INFO, format="%(asctime)s [Orchestrateur] %(message)s")


# ================================================================
# 1️⃣ Types XML utilisés dans l'orchestration
# ================================================================

class InformationsExtraites(ComplexModel):
    nom = Unicode
    adresse = Unicode
    montant_pret = Float
    duree = Integer
    revenus_mensuels = Float
    description = Unicode


class SolvabiliteResult(ComplexModel):
    id_demande = Integer
    nom = Unicode
    revenu_mensuel = Float
    charges_mensuelles = Float
    montant_pret = Float
    taux_endettement = Float
    score_credit = Float
    niveau_risque = Unicode
    decision = Unicode
    historique_credit = Unicode  
    erreur = Unicode



class ProprieteResult(ComplexModel):
    id_demande = Integer
    valeur_estimee = Float
    conformite = Unicode
    description = Unicode
    message = Unicode
    erreur = Unicode


class DecisionResult(ComplexModel):
    id_demande = Integer
    montant_pret = Float       
    valeur_bien = Float       
    taux_endettement = Float    
    decision_finale = Unicode
    taux_interet = Float         
    motif = Unicode
    erreur = Unicode


class EvaluationResult(ComplexModel):
    id_demande = Integer
    informations_extraites = InformationsExtraites
    solvabilite = SolvabiliteResult
    propriete = ProprieteResult
    decision = DecisionResult


# ================================================================
# 2️⃣ Service Orchestrateur
# ================================================================

class OrchestrateurService(ServiceBase):
    """Service composite qui orchestre les 4 services SOAP XML typés."""

    @rpc(Unicode, Integer, _returns=EvaluationResult)
    def evaluateLoan(ctx, texte_demande, id_demande):
        id_demande = int(id_demande)
        logging.info(f"[Orchestrateur] Évaluation du prêt ID={id_demande}")

        try:
            # === 1. Appel au service IE ===
            ie_client = Client("http://ie_service:8001/IEService?wsdl", transport=Transport())
            ie_result = ie_client.service.extractInfo(texte_demande, id_demande)
            logging.info("[IE] Extraction terminée")

            # --- On extrait les infos dans un dict neutre ---
            ie_info = {
                "nom": ie_result.informations_extraites.nom,
                "adresse": ie_result.informations_extraites.adresse,
                "montant_pret": ie_result.informations_extraites.montant_pret,
                "duree": ie_result.informations_extraites.duree,
                "revenus_mensuels": ie_result.informations_extraites.revenus_mensuels,
                "description": ie_result.informations_extraites.description,
            }

            # === 2. Appel au service Solvabilité ===
            solv_client = Client("http://solvabilite_service:8002/SolvabiliteService?wsdl", transport=Transport())
            solv_ie_type = solv_client.get_type("ns0:InformationsExtraites")
            solv_info = solv_ie_type(**ie_info)
            solv_result = solv_client.service.checkSolvabilite(solv_info, id_demande)
            logging.info("[Solvabilité] Vérification terminée")

            # === 3. Appel au service Propriété ===
            prop_client = Client("http://propriete_service:8003/ProprieteService?wsdl", transport=Transport())
            prop_ie_type = prop_client.get_type("ns0:InformationsExtraites")
            prop_info = prop_ie_type(**ie_info)
            prop_result = prop_client.service.evaluateProperty(prop_info, id_demande)
            logging.info("[Propriété] Évaluation terminée")

            # === 4. Appel au service Décision ===
            # === 4. Appel au service Décision ===
            dec_client = Client("http://decision_service:8004/DecisionService?wsdl", transport=Transport())

            # Récupération des bons types depuis le WSDL du service Décision
            SolvabiliteType = dec_client.get_type("ns0:SolvabiliteResult")
            ProprieteType = dec_client.get_type("ns0:ProprieteResult")

            # Construction des objets avec les bons namespaces
            solv_for_dec = SolvabiliteType(
                id_demande=solv_result.id_demande,
                nom=solv_result.nom,
                revenu_mensuel=solv_result.revenu_mensuel,
                charges_mensuelles=solv_result.charges_mensuelles,
                montant_pret=solv_result.montant_pret,
                taux_endettement=solv_result.taux_endettement,
                historique_credit=getattr(solv_result, "historique_credit", None),
                score_credit=solv_result.score_credit,
                niveau_risque=solv_result.niveau_risque,
                decision=solv_result.decision,
            )

            prop_for_dec = ProprieteType(
                id_demande=prop_result.id_demande,
                valeur_estimee=prop_result.valeur_estimee,
                conformite=prop_result.conformite,
                description=prop_result.description,
                message=prop_result.message,
            )

            dec_result = dec_client.service.takeDecision(solv_for_dec, prop_for_dec, id_demande)
            logging.info("[Décision] Décision finale terminée")




            # === 5. Agrégation ===
            evaluation = EvaluationResult()
            evaluation.id_demande = id_demande
            evaluation.informations_extraites = ie_result.informations_extraites
            evaluation.solvabilite = solv_result
            evaluation.propriete = prop_result
            evaluation.decision = dec_result

            logging.info(f"[Orchestrateur] ✅ Processus complet pour ID={id_demande}")
            return evaluation

        except Fault as f:
            logging.error(f"[SOAP Fault] {f}")
            raise
        except Exception as e:
            logging.error(f"[Orchestrateur] Erreur inattendue : {e}")
            raise


# ================================================================
# 3️⃣ Application SOAP Spyne
# ================================================================
application = Application(
    [OrchestrateurService],
    tns='spyne.service.orch',
    in_protocol=Soap11(validator='lxml'),
    out_protocol=Soap11()
)

if __name__ == '__main__':
    wsgi_app = WsgiApplication(application)
    twisted_apps = [(wsgi_app, b'OrchestrateurService')]
    logging.info("Service Orchestrateur (XML typé) démarré sur le port 8000 ...")
    sys.exit(run_twisted(twisted_apps, 8000))
