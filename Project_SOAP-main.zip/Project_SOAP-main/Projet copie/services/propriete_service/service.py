import logging
import sys
from spyne import Application, rpc, ServiceBase, Unicode, Integer, Float, ComplexModel
from spyne.protocol.soap import Soap11
from spyne.server.wsgi import WsgiApplication
from spyne.util.wsgi_wrapper import run_twisted

logging.basicConfig(level=logging.INFO, format="%(asctime)s [Propriété] %(message)s")


# ================================================================
# 1️⃣ Types XML (définis pour le schéma XSD via Spyne)
# ================================================================

class InformationsExtraites(ComplexModel):
    """Reprise du modèle du service IE."""
    nom = Unicode
    adresse = Unicode
    montant_pret = Float
    duree = Integer
    revenus_mensuels = Float
    description = Unicode


class ProprieteResult(ComplexModel):
    """Structure XML de réponse du service Propriété."""
    id_demande = Integer
    valeur_estimee = Float
    conformite = Unicode
    description = Unicode
    message = Unicode
    erreur = Unicode


# ================================================================
# 2️⃣ Service SOAP
# ================================================================

class ProprieteService(ServiceBase):
    """Service d'évaluation de la propriété immobilière (XML typé)."""

    @rpc(InformationsExtraites, Integer, _returns=ProprieteResult)
    def evaluateProperty(ctx, infos_ie, id_demande):
        logging.info(f"Évaluation de la propriété pour la demande ID={id_demande}")

        try:
            description = (infos_ie.description or "").lower()
            montant_pret = float(infos_ie.montant_pret or 0)

            # --- 1. Estimation simplifiée de la valeur du bien ---
            if montant_pret > 0:
                valeur_estimee = montant_pret * 1.2  # 20% au-dessus du montant demandé
                message = "Valeur estimée basée sur le montant du prêt."
            else:
                valeur_estimee = 200000.0
                message = "Valeur par défaut appliquée (aucun montant fourni)."

            # --- 2. Vérification de conformité simple ---
            conforme = "conforme" if any(word in description for word in ["appartement", "maison", "villa"]) else "à vérifier"

            # --- 3. Construction du résultat XML typé ---
            res = ProprieteResult()
            res.id_demande = id_demande
            res.valeur_estimee = round(valeur_estimee, 2)
            res.conformite = conforme
            res.description = description
            res.message = message
            res.erreur = ""

            logging.info(f"✅ Évaluation terminée pour ID={id_demande} (valeur estimée {res.valeur_estimee})")
            return res

        except Exception as e:
            logging.error(f"Erreur propriété : {e}")
            err = ProprieteResult()
            err.id_demande = id_demande
            err.erreur = str(e)
            return err


# ================================================================
# 3️⃣ Application SOAP
# ================================================================
application = Application(
    [ProprieteService],
    tns='spyne.service.prop',
    in_protocol=Soap11(validator='lxml'),
    out_protocol=Soap11()
)

if __name__ == '__main__':
    wsgi_app = WsgiApplication(application)
    twisted_apps = [(wsgi_app, b'ProprieteService')]
    logging.info("Service Propriété (XML typé) démarré sur le port 8003 ...")
    sys.exit(run_twisted(twisted_apps, 8003))
