import pytest

# --- Fonction à tester : ComputeCreditScore ---
def compute_credit_score(debt, late, bankruptcy):
    return 1000 - 0.1 * debt - 50 * late - (200 if bankruptcy else 0)

# --- Fonction à tester : DecideSolvency ---
def decide_solvency(income, expenses, score):
    return "solvent" if score >= 700 and income > expenses else "not_solvent"

# ============================================================
# ✅ TESTS UNITAIRES
# ============================================================

def test_compute_credit_score():
    assert compute_credit_score(5000, 2, False) == 400
    assert compute_credit_score(2000, 0, False) == 800
    assert compute_credit_score(10000, 5, True) == -450

def test_decide_solvency():
    assert decide_solvency(3000, 2500, 800) == "solvent"
    assert decide_solvency(4000, 3000, 400) == "not_solvent"
    assert decide_solvency(6000, 5500, -450) == "not_solvent"
