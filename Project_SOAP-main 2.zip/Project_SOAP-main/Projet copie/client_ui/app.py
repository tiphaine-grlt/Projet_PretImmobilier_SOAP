import streamlit as st
import os
import json
import time
import re
from xml.etree import ElementTree as ET

# --- Chemins ---
USERS_FILE = "./users.json"
DEMANDES_DIR = "./demandes"
RESULTATS_DIR = "./resultats"

st.set_page_config(page_title="Service Prêt Immobilier", page_icon="🏠", layout="centered")

# ----------------------------------------------------------
# Fonctions utilitaires
# ----------------------------------------------------------

def load_users():
    with open(USERS_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def check_credentials(username, password, users):
    return username in users and users[username]["password"] == password

def login_screen(users):
    st.markdown("<h2 style='text-align:center;'>🔐 Connexion à la plateforme</h2>", unsafe_allow_html=True)
    with st.form("login_form", clear_on_submit=True):
        username = st.text_input("Nom d'utilisateur")
        password = st.text_input("Mot de passe", type="password")
        submitted = st.form_submit_button("Se connecter")
        if submitted:
            if check_credentials(username, password, users):
                st.session_state["logged_in"] = True
                st.session_state["username"] = username
                st.session_state["user_id"] = users[username]["id"]
                st.success(f"Bienvenue {username} 👋")
                st.rerun()
            else:
                st.error("Nom d'utilisateur ou mot de passe incorrect.")

def logout_button():
    st.markdown("---")
    if st.button("🚪 Se déconnecter"):
        st.session_state.clear()
        st.rerun()

# ----------------------------------------------------------
# Extraction XML
# ----------------------------------------------------------

def extraire_decision(xml_content):
    """Extrait la décision finale et le motif, en gérant les namespaces."""
    try:
        root = ET.fromstring(xml_content)
        ns = {
            "soap": "http://schemas.xmlsoap.org/soap/envelope/",
            "tns": "spyne.service.orch"
        }
        decision_node = root.find(".//tns:decision_finale", ns)
        motif_node = root.find(".//tns:motif", ns)
        decision = decision_node.text.strip().upper() if decision_node is not None else None
        motif = motif_node.text.strip() if motif_node is not None else None
        return decision, motif
    except Exception:
        return None, None

# ----------------------------------------------------------
# Affichage résultats
# ----------------------------------------------------------

def afficher_resultats(result_path):
    """Affiche le résultat (XML ou JSON)."""
    with open(result_path, "r", encoding="utf-8") as f:
        contenu = f.read()

    st.markdown("### 📄 Résultat du traitement")

    decision, motif = extraire_decision(contenu)

    if decision and "APPROUV" in decision:
        st.markdown(
            "<div style='background-color:#d4edda;padding:15px;border-radius:10px;text-align:center;'>"
            f"<h2 style='color:#155724;'>✅ DEMANDE APPROUVÉE</h2>"
            f"<p><b>Motif :</b> {motif or '—'}</p></div>",
            unsafe_allow_html=True,
        )
    elif decision and ("REFUS" in decision or "REJET" in decision):
        st.markdown(
            "<div style='background-color:#f8d7da;padding:15px;border-radius:10px;text-align:center;'>"
            f"<h2 style='color:#721c24;'>❌ DEMANDE REFUSÉE</h2>"
            f"<p><b>Motif :</b> {motif or '—'}</p></div>",
            unsafe_allow_html=True,
        )
    else:
        st.info("⚙️ Décision non trouvée dans le résultat.")

    with st.expander("🧾 Contenu XML complet"):
        st.code(contenu, language="xml")

    # Téléchargement
    with open(result_path, "rb") as f:
        file_bytes = f.read()
    st.download_button(
        label="⬇️ Télécharger le résultat complet",
        data=file_bytes,
        file_name=os.path.basename(result_path),
        mime="application/xml"
    )

# ----------------------------------------------------------
# Application principale
# ----------------------------------------------------------

os.makedirs(DEMANDES_DIR, exist_ok=True)
os.makedirs(RESULTATS_DIR, exist_ok=True)
users = load_users()

if "logged_in" not in st.session_state:
    st.session_state["logged_in"] = False

if not st.session_state["logged_in"]:
    login_screen(users)
else:
    user_id = st.session_state["user_id"]
    username = st.session_state["username"]

    st.markdown(f"### 🏠 Portail de Prêt Immobilier — Bonjour **{username}** !")
    logout_button()
    st.markdown("---")

    # Dossiers utilisateur
    # Nettoyer le nom d'utilisateur pour éviter espaces et caractères spéciaux
    safe_username = re.sub(r'[^a-zA-Z0-9_-]', '_', username.strip().lower())

    # Dossiers utilisateur (basés sur le nom)
    user_demande_dir = os.path.join(DEMANDES_DIR, safe_username)
    user_result_dir = os.path.join(RESULTATS_DIR, safe_username)

    os.makedirs(user_demande_dir, exist_ok=True)
    os.makedirs(user_result_dir, exist_ok=True)


    # Upload fichier
    st.markdown("### 📤 Déposez votre demande")
    uploaded_file = st.file_uploader("Choisissez un fichier .txt", type=["txt"])

    if uploaded_file is not None:
        # 🔹 Génération automatique du nom de fichier
        existing = [f for f in os.listdir(user_demande_dir) if f.startswith(f"demande_{username}_") and f.endswith(".txt")]
        num = len(existing) + 1
        nom_fichier = f"demande_{username}_{num}.txt"

        chemin_demande = os.path.join(user_demande_dir, nom_fichier)
        with open(chemin_demande, "wb") as f:
            f.write(uploaded_file.getbuffer())

        st.success(f"✅ Fichier enregistré : {chemin_demande}")
        st.info("⏳ En attente du traitement...")

        id_demande = num  # ID numérique simple pour correspondance watcher
        result_path = os.path.join(user_result_dir, f"demande_{username}_{id_demande}_result.xml")

        timeout, elapsed = 60, 0
        with st.spinner("Traitement en cours..."):
            while not os.path.exists(result_path) and elapsed < timeout:
                time.sleep(2)
                elapsed += 2

        if os.path.exists(result_path):
            afficher_resultats(result_path)
        else:
            st.error("⛔ Aucun résultat trouvé. Le watcher n’a peut-être pas encore traité la demande.")
