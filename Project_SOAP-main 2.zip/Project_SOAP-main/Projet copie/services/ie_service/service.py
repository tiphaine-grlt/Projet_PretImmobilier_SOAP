import logging
import re
from spyne import Application, rpc, ServiceBase, Unicode, Integer, ComplexModel, Float
from spyne.protocol.soap import Soap11
from spyne.server.wsgi import WsgiApplication
from spyne.util.wsgi_wrapper import run_twisted

logging.basicConfig(level=logging.INFO, format="%(asctime)s [IE] %(message)s")


# ================================================================
# Définition des types structurés (XSD via Spyne)
# ================================================================

class InformationsExtraites(ComplexModel):
    """Structure XML pour les informations extraites du texte."""
    nom = Unicode
    adresse = Unicode
    montant_pret = Float
    duree = Integer
    revenus_mensuels = Float
    description = Unicode


class ExtractionResult(ComplexModel):
    """Structure XML de réponse du service IE."""
    id_demande = Integer
    informations_extraites = InformationsExtraites
    etat = Unicode
    champs_manquants = Unicode  


# ================================================================
# Service SOAP Spyne
# ================================================================

class IEService(ServiceBase):
    """Service d’Extraction d’Information (IE) métiers — version XML typée."""

    @rpc(Unicode, Integer, _returns=ExtractionResult)
    def extractInfo(ctx, texte_demande, id_demande):
        logging.info(f"Début extraction pour la demande ID={id_demande}")

        try:
            # --- 1. Prétraitement du texte ---
            clean_text = IEService.preprocess_text(texte_demande)

            # --- 2. Extraction des entités ---
            info = InformationsExtraites()
            info.nom = IEService.extract_nom(clean_text)
            info.adresse = IEService.extract_adresse(clean_text)
            info.montant_pret = IEService.extract_montant(clean_text)
            info.duree = IEService.extract_duree(clean_text)
            info.revenus_mensuels = IEService.extract_revenus(clean_text)
            info.description = IEService.extract_description(clean_text)

            # --- 3. Champs manquants ---
            missing = [
                field for field in [
                    "nom", "adresse", "montant_pret", "duree",
                    "revenus_mensuels", "description"
                ]
                if getattr(info, field) in (None, "")
            ]

            etat = "succès" if not missing else "partiel"
            if missing:
                logging.warning(f"Champs non trouvés : {', '.join(missing)}")

            # --- 4. Construction du résultat XML typé ---
            result = ExtractionResult()
            result.id_demande = id_demande
            result.informations_extraites = info
            result.etat = etat
            result.champs_manquants = ", ".join(missing)

            logging.info(f"Extraction terminée pour ID={id_demande}")
            return result

        except Exception as e:
            logging.error(f"Erreur extraction IE : {e}")
            err = ExtractionResult()
            err.id_demande = id_demande
            err.informations_extraites = InformationsExtraites()
            err.etat = "erreur"
            err.champs_manquants = str(e)
            return err


    # ================================================================
    # Fonctions utilitaires
    # ================================================================

    @staticmethod
    def preprocess_text(text):
        """Nettoie et normalise le texte."""
        text = text.replace('\n', ' ')
        text = re.sub(r'\s+', ' ', text)
        return text.strip().lower()

    @staticmethod
    def extract_nom(text):
        match = re.search(r"nom\s*:\s*([a-zéèêëàâäîïôöùûüç'\- ]+?)(?=\s+(adresse|montant|revenu|durée|description|$))", text)
        return match.group(1).title().strip() if match else None

    @staticmethod
    def extract_adresse(text):
        match = re.search(r"adresse\s*:\s*(.+?)(?= montant| durée| revenus| description|$)", text)
        return match.group(1).strip().capitalize() if match else None

    @staticmethod
    def extract_montant(text):
        match = re.search(r"montant du prêt demandé\s*:\s*([\d\s]+)\s*euros", text)
        return int(match.group(1).replace(" ", "")) if match else None

    @staticmethod
    def extract_duree(text):
        match = re.search(r"durée souhaitée\s*:\s*(\d+)\s*ans", text)
        return int(match.group(1)) if match else None

    @staticmethod
    def extract_revenus(text):
        match = re.search(r"revenus mensuels\s*:\s*([\d\s]+)\s*euros", text)
        return int(match.group(1).replace(" ", "")) if match else None

    @staticmethod
    def extract_description(text):
        match = re.search(r"description de la propriété\s*:\s*(.+)", text)
        return match.group(1).strip().capitalize() if match else None


# ================================================================
# Application Spyne SOAP
# ================================================================
application = Application(
    [IEService],
    tns='spyne.service.ie',
    in_protocol=Soap11(validator='lxml'),
    out_protocol=Soap11()
)

if __name__ == '__main__':
    wsgi_app = WsgiApplication(application)
    twisted_apps = [(wsgi_app, b'IEService')]
    logging.info("Service IE (typé XML) démarré sur le port 8001 ...")
    import sys
    sys.exit(run_twisted(twisted_apps, 8001))
