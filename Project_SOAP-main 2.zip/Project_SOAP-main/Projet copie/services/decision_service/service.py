import logging
import sys
from spyne import Application, rpc, ServiceBase, Unicode, Integer, Float, ComplexModel
from spyne.protocol.soap import Soap11
from spyne.server.wsgi import WsgiApplication
from spyne.util.wsgi_wrapper import run_twisted

logging.basicConfig(level=logging.INFO, format="%(asctime)s [Décision] %(message)s")


# ================================================================
# Types XML (modèles XSD via Spyne)
# ================================================================

class SolvabiliteResult(ComplexModel):
    id_demande = Integer
    nom = Unicode
    revenu_mensuel = Float
    charges_mensuelles = Float
    montant_pret = Float
    taux_endettement = Float
    score_credit = Float
    niveau_risque = Unicode
    decision = Unicode
    historique_credit = Unicode
    erreur = Unicode



class ProprieteResult(ComplexModel):
    id_demande = Integer
    valeur_estimee = Float
    conformite = Unicode
    description = Unicode
    message = Unicode
    erreur = Unicode


class DecisionResult(ComplexModel):
    id_demande = Integer
    montant_pret = Float       
    valeur_bien = Float         
    taux_endettement = Float    
    decision_finale = Unicode
    taux_interet = Float        
    motif = Unicode
    erreur = Unicode



# ================================================================
# Service SOAP
# ================================================================

class DecisionService(ServiceBase):
    """Service de décision finale d'approbation ou de refus du prêt (XML typé)."""

    @rpc(SolvabiliteResult, ProprieteResult, Integer, _returns=DecisionResult)
    def takeDecision(ctx, solvabilite, propriete, id_demande):
        logging.info(f"Prise de décision pour la demande ID={id_demande}")

        try:
            revenu = solvabilite.revenu_mensuel or 0
            taux_endettement = solvabilite.taux_endettement or 1
            decision_solv = solvabilite.decision or ""
            valeur_bien = propriete.valeur_estimee or 0
            montant_pret = solvabilite.montant_pret or 0
            conforme = propriete.conformite or "à vérifier"

            # --- Règles métier ---
            decision_finale = "REFUSÉ"
            motif = ""
            taux_interet = 0.0

            if montant_pret == 0 or valeur_bien == 0:
                motif = "Données financières incomplètes."
            elif taux_endettement > 0.35:
                motif = f"Taux d'endettement trop élevé ({taux_endettement:.2f})."
            elif valeur_bien < montant_pret:
                motif = "Montant du prêt supérieur à la valeur estimée du bien."
            elif "non solvable" in decision_solv.lower() or "risque" in decision_solv.lower():
                motif = "Client jugé non solvable ou à risque."
            elif conforme != "conforme":
                motif = "Conformité du bien à vérifier."
            else:
                decision_finale = "APPROUVÉ"
                taux_interet = 3.5 if taux_endettement < 0.3 else 4.2
                motif = "Demande approuvée selon les critères établis."

            # --- Résultat XML typé ---
            res = DecisionResult()
            res.id_demande = id_demande
            res.montant_pret = montant_pret
            res.valeur_bien = valeur_bien
            res.taux_endettement = round(taux_endettement, 2)
            res.decision_finale = decision_finale
            res.taux_interet = taux_interet
            res.motif = motif
            res.erreur = ""

            logging.info(f"Décision finale pour ID={id_demande} → {decision_finale}")
            return res

        except Exception as e:
            logging.error(f"Erreur décision : {e}")
            err = DecisionResult()
            err.id_demande = id_demande
            err.erreur = str(e)
            return err


# ================================================================
# Application SOAP
# ================================================================
application = Application(
    [DecisionService],
    tns='spyne.service.decision',
    in_protocol=Soap11(validator='lxml'),
    out_protocol=Soap11()
)

if __name__ == '__main__':
    wsgi_app = WsgiApplication(application)
    twisted_apps = [(wsgi_app, b'DecisionService')]
    logging.info("Service Décision (XML typé) démarré sur le port 8004 ...")
    sys.exit(run_twisted(twisted_apps, 8004))
