import logging
import sys
import json
import time
import re
from pathlib import Path
from spyne import Application, rpc, ServiceBase, Unicode, Integer, Float, ComplexModel, Fault
from spyne.protocol.soap import Soap11
from spyne.server.wsgi import WsgiApplication
from spyne.util.wsgi_wrapper import run_twisted

logging.basicConfig(level=logging.INFO, format="%(asctime)s [Solvabilité] %(message)s")

DATA_PATH = Path("/app/clients_data.json")


# ================================================================
# Types XML (XSD via Spyne)
# ================================================================

class InformationsExtraites(ComplexModel):
    """Reprise du modèle du service IE."""
    nom = Unicode
    adresse = Unicode
    montant_pret = Float
    duree = Integer
    revenus_mensuels = Float
    description = Unicode


class SolvabiliteResult(ComplexModel):
    """Structure XML de réponse de la solvabilité."""
    id_demande = Integer
    nom = Unicode
    revenu_mensuel = Float
    charges_mensuelles = Float
    montant_pret = Float
    taux_endettement = Float
    score_credit = Float
    niveau_risque = Unicode
    decision = Unicode
    erreur = Unicode  


# ================================================================
# Service SOAP Spyne avec QoS + Sécurité minimale
# ================================================================

class SolvabiliteService(ServiceBase):
    """Service de vérification de la solvabilité du client (XML typé)."""

    # --- QoS Metrics ---
    total_calls = 0
    total_latency_ms = 0.0

    @rpc(InformationsExtraites, Integer, _returns=SolvabiliteResult)
    def checkSolvabilite(ctx, infos_ie, id_demande):
        start_time = time.time()
        SolvabiliteService.total_calls += 1

        try:
            # --- Validation d'entrée ---
            if infos_ie is None or not isinstance(infos_ie, InformationsExtraites):
                raise Fault(faultcode="Client.ValidationError",
                            faultstring="Format de requête invalide : InformationsExtraites attendu")

            # --- Sécurité basique : filtrage caractères XML dangereux ---
            nom = re.sub(r"[<>&]", "", infos_ie.nom.strip().title()) if infos_ie.nom else None
            montant_pret = float(infos_ie.montant_pret or 0)

            # --- Validation du nom client ---
            if not nom or any(char.isdigit() for char in nom):
                raise Fault(faultcode="Client.ValidationError",
                            faultstring=f"Identifiant client invalide : '{nom}'")

            # --- Chargement des données client ---
            if not DATA_PATH.exists():
                raise Fault(faultcode="Server.DataError",
                            faultstring="Fichier clients_data.json introuvable")

            with open(DATA_PATH, "r", encoding="utf-8") as f:
                clients_data = json.load(f)

            # --- Recherche du client ---
            client_data = clients_data.get(nom)
            if not client_data:
                raise Fault(faultcode="Client.NotFound",
                            faultstring=f"Aucune donnée trouvée pour le client '{nom}'")

            # --- Extraction des données financières ---
            revenus = float(client_data.get("revenus_mensuels", 0))
            charges = float(client_data.get("charges_mensuelles", 0))
            dettes = float(client_data.get("dettes", 0))
            retards = int(client_data.get("retards_paiements", 0))
            faillite = bool(client_data.get("faillite", False))

            # --- Calcul du score de crédit ---
            score_credit = 1000 - 0.1 * dettes - 50 * retards - (200 if faillite else 0)

            # --- Calcul du taux d’endettement ---
            taux_endettement = round((charges + montant_pret / 240) / revenus, 2) if revenus > 0 else 1.0

            # --- Décision ---
            solvable = score_credit >= 700 and revenus > charges
            niveau_risque = (
                "faible" if score_credit >= 750
                else "modéré" if score_credit >= 600
                else "élevé"
            )
            decision = "Client solvable " if solvable else "Client à risque "

            # --- Construction du résultat ---
            res = SolvabiliteResult()
            res.id_demande = id_demande
            res.nom = nom
            res.revenu_mensuel = revenus
            res.charges_mensuelles = charges
            res.montant_pret = montant_pret
            res.taux_endettement = taux_endettement
            res.score_credit = round(score_credit, 2)
            res.niveau_risque = niveau_risque
            res.decision = decision
            res.erreur = ""

            logging.info(f"Solvabilité calculée pour {nom} : score={score_credit:.2f}, décision={decision}")
            return res

        except Fault as fault:
            logging.warning(f"SOAP Fault : {fault.faultcode} - {fault.faultstring}")
            raise

        except Exception as e:
            logging.error(f"Erreur inattendue solvabilité: {e}")
            raise Fault(faultcode="Server.InternalError", faultstring=str(e))

        finally:
            # --- Mesure de la latence et calcul de la moyenne ---
            latency_ms = (time.time() - start_time) * 1000
            SolvabiliteService.total_latency_ms += latency_ms
            moyenne = SolvabiliteService.total_latency_ms / SolvabiliteService.total_calls
            logging.info(
                f"[QoS] Appels totaux={SolvabiliteService.total_calls} | "
                f"Latence actuelle={latency_ms:.2f}ms | Moyenne={moyenne:.2f}ms"
            )


# ================================================================
# Application SOAP Spyne
# ================================================================
application = Application(
    [SolvabiliteService],
    tns='spyne.service.solv',
    in_protocol=Soap11(validator='lxml'),
    out_protocol=Soap11()
)

if __name__ == '__main__':
    wsgi_app = WsgiApplication(application)
    twisted_apps = [(wsgi_app, b'SolvabiliteService')]
    logging.info("Service Solvabilité (QoS + validation XML) démarré sur le port 8002 ...")
    sys.exit(run_twisted(twisted_apps, 8002))

