from zeep import Client
from zeep.exceptions import Fault
import sys

# Adresse du service (depuis ton conteneur ou localhost)
WSDL_URL = "http://localhost:8002/SolvabiliteService?wsdl"

client = Client(WSDL_URL)

# Type XML généré par Spyne
InfoType = client.get_type("ns0:InformationsExtraites")


def test_client(client_id, nom, adresse, montant_pret, duree, revenus, desc):
    infos = InfoType(
        nom=nom,
        adresse=adresse,
        montant_pret=montant_pret,
        duree=duree,
        revenus_mensuels=revenus,
        description=desc,
    )
    result = client.service.checkSolvabilite(infos, 1)
    print(f"\nTest {nom}")
    print(f"Score crédit : {result.score_credit}")
    print(f"Décision     : {result.decision}\n")
    return result


# === Cas nominaux ===
print("=== CAS NOMINAUX ===")

r1 = test_client("client-001", "John Doe", "123 Main St", 200000, 20, 4000, "Maison familiale")
assert r1.score_credit == 400.0
assert "risque" in r1.decision.lower()

r2 = test_client("client-002", "Alice Smith", "456 Elm St", 150000, 15, 3000, "Appartement lumineux")
assert r2.score_credit == 800.0
assert "solvable" in r2.decision.lower()

r3 = test_client("client-003", "Bob Johnson", "789 Oak St", 250000, 25, 6000, "Grande maison avec piscine")
assert r3.score_credit == -450.0
assert "risque" in r3.decision.lower()

# === Cas d’erreur ===
print("=== CAS D’ERREUR ===")

try:
    infos = InfoType(
        nom="Inconnu",
        adresse="Quelque part",
        montant_pret=100000,
        duree=10,
        revenus_mensuels=2500,
        description="Test erreur not found",
    )
    client.service.checkSolvabilite(infos, 1)
except Fault as f:
    print("Erreur attendue Client.NotFound :", f)

try:
    client.service.checkSolvabilite("abc", 1)
except Exception as e:
    print("Erreur attendue Client.ValidationError :", e)

print("\n Tous les tests d’intégration SOAP terminés avec succès.")
